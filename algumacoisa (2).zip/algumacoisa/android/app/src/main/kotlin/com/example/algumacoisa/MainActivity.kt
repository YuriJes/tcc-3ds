package com.example.algumacoisa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
