import 'package:flutter/material.dart';
import 'sanguineo_paciente.dart';

class IdadePaciente extends StatefulWidget {
  const IdadePaciente({super.key});

  @override
  State<IdadePaciente> createState() => _IdadePacienteState();
}

class _IdadePacienteState extends State<IdadePaciente> {
  final FixedExtentScrollController _scrollController =
      FixedExtentScrollController(initialItem: 19);
  int _currentAge = 19;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      setState(() {
        _currentAge = _scrollController.selectedItem;
      });
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Qual é a sua idade?',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlue,
                ),
              ),
              const SizedBox(height: 50),
              SizedBox(
                height: 200,
                child: ListWheelScrollView.useDelegate(
                  controller: _scrollController,
                  itemExtent: 70,
                  perspective: 0.005,
                  physics: const FixedExtentScrollPhysics(),
                  onSelectedItemChanged: (index) {
                    setState(() {
                      _currentAge = index;
                    });
                  },
                  childDelegate: ListWheelChildBuilderDelegate(
                    builder: (context, index) {
                      final isSelected = index == _currentAge;
                      return Center(
                        child: Text(
                          index.toString(),
                          style: TextStyle(
                            fontSize: isSelected ? 48 : 24,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            color: isSelected ? Colors.lightBlue.shade400 : Colors.grey[400],
                          ),
                        ),
                      );
                    },
                    childCount: 100,
                  ),
                ),
              ),
              const SizedBox(height: 100),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const SanguineoPaciente()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue.shade400,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}