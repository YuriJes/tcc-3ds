import 'package:flutter/material.dart';
import 'package:algumacoisa/paciente/MeuPerfil_paciente.dart';
import 'package:algumacoisa/paciente/configuracoes_screen.dart';
import 'package:algumacoisa/paciente/historicoregistro_paciente.dart';
import 'package:algumacoisa/paciente/home_paciente.dart';
import 'package:algumacoisa/paciente/infoPessoais_paciente.dart';
import 'package:algumacoisa/paciente/login_screen%20copy.dart';
import 'package:algumacoisa/paciente/meucuidador_paciente.dart';
import 'package:algumacoisa/paciente/politica_privacidade_screen.dart';
import 'MeuPerfil_paciente.dart';

class PerfilPaciente extends StatelessWidget {
  const PerfilPaciente({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePaciente()),
                );
          },
        ),
        title: Text('Meu Perfil'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            SizedBox(height: 20),
            Stack(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/Paulosikera.jpg'), // Substitua com sua imagem
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: CircleAvatar(
                    radius: 15,
                    backgroundColor: Colors.blue,
                    child: Icon(Icons.edit, size: 16, color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Text('Paulo Silva', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 30),
            _buildProfileItem(
              context,
              icon: Icons.person_outline,
              label: 'Perfil',
              onTap: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MeuperfilPaciente()),
                );
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.lock_outline,
              label: 'Política de Privacidade',
              onTap: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliticaPrivacidadePaciente()),
                );
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.settings_outlined,
              label: 'Configurações',
              onTap: () {
               Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ConfiguracoesPaciente()),
                );
              
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.logout,
              label: 'Sair',
              onTap: () {
                _showLogoutDialog(context);
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.person_outline,
              label: 'Informações Pessoais',
              onTap: () {
             Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InformacoesPessoais()),
                );
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.favorite_border, // Corrigido para corresponder à imagem
              label: 'Meu Cuidador',
              onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MeuCuidador()),
                );
              },
            ),
            _buildProfileItem(
              context,
              icon: Icons.description_outlined, // Corrigido para corresponder à imagem
              label: 'Historico De Registros',
              onTap: () {
               Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HistoricoDeRegistros()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Sair'),
          content: Text('Você realmente quer sair?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPaciente()),
                  (Route<dynamic> route) => false,
                );
              },
              child: Text('Sim, Sair'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildProfileItem(BuildContext context, {required IconData icon, required String label, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        child: Row(
          children: [
            Icon(icon, color: Colors.blue.shade700),
            SizedBox(width: 20),
            Expanded(
              child: Text(label, style: TextStyle(fontSize: 16)),
            ),
            Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }
}