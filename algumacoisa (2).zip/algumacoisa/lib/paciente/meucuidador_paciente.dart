import 'package:flutter/material.dart';

class MeuCuidador extends StatelessWidget {
  const MeuCuidador({super.key});

  Widget _buildInfoCard(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 16, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade300, width: 2),
          ),
          child: Text(
            value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Meu Cuidador',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlue,
                ),
              ),
              const SizedBox(height: 40),
              const CircleAvatar(
                radius: 50,
                backgroundImage:
                    AssetImage('assets/carolina.png'), // Imagem de exemplo
              ),
              const SizedBox(height: 40),
              _buildInfoCard('Nome Completo', 'Carolina Martins'),
              const SizedBox(height: 10),
              _buildInfoCard('Numero De Telefone', '+666 999 99999'),
              const SizedBox(height: 10),
              _buildInfoCard('Email', 'carolina@gmail.com'),
              const SizedBox(height: 10),
              _buildInfoCard('Data Dos Cuidados', 'Desde 03/11/2024'),
            ],
          ),
        ),
      ),
    );
  }
}
