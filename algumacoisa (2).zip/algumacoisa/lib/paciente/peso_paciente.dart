import 'package:flutter/material.dart';
import 'package:algumacoisa/paciente/idade_paciente.dart';

class PesoPaciente extends StatefulWidget {
  const PesoPaciente({super.key});

  @override
  State<PesoPaciente> createState() => _PesoPacienteState();
}

class _PesoPacienteState extends State<PesoPaciente> {
  double _currentWeight = 140.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Qual é o seu peso?',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlue,
                ),
              ),
              const SizedBox(height: 100),
              Center(
                child: Column(
                  children: [
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: _currentWeight.toStringAsFixed(0),
                            style: const TextStyle(
                              fontSize: 80,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                          const TextSpan(
                            text: ' Kg',
                            style: TextStyle(
                              fontSize: 24,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                    SliderTheme(
                      data: SliderThemeData(
                        thumbColor: Colors.lightBlue.shade400,
                        activeTrackColor: Colors.lightBlue.shade400,
                        inactiveTrackColor: Colors.lightBlue.withOpacity(0.1),
                        trackHeight: 2,
                      ),
                      child: Slider(
                        value: _currentWeight,
                        min: 30,
                        max: 200,
                        divisions: 170,
                        onChanged: (double value) {
                          setState(() {
                            _currentWeight = value;
                          });
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('30', style: TextStyle(color: Colors.grey[600])),
                        Text('200', style: TextStyle(color: Colors.grey[600])),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 200), // Espaçamento para empurrar o botão para baixo
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const IdadePaciente()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue.shade400,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}