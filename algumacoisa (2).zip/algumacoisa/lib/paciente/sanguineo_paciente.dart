import 'package:flutter/material.dart';
import 'package:algumacoisa/paciente/comorbidade_paciente.dart';

class SanguineoPaciente extends StatefulWidget {
  const SanguineoPaciente({super.key});

  @override
  State<SanguineoPaciente> createState() => _SanguineoPacienteState();
}

class _SanguineoPacienteState extends State<SanguineoPaciente> {
  String? _selectedBloodType;
  String? _selectedRhFactor;

  Widget _buildBloodTypeButton(String type) {
    final isSelected = _selectedBloodType == type;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedBloodType = type;
        });
      },
      child: Container(
        width: 60,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected
              ? Colors.lightBlue.shade400.withOpacity(0.2)
              : Colors.lightBlue.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          type,
          style: TextStyle(
            color: isSelected ? Colors.lightBlue.shade400 : Colors.black,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildRhFactorButton(String factor) {
    final isSelected = _selectedRhFactor == factor;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedRhFactor = factor;
          });
        },
        child: Container(
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: isSelected
                ? Colors.lightBlue.shade400.withOpacity(0.2)
                : Colors.lightBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(30),
          ),
          child: Text(
            factor,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.lightBlue.shade400 : Colors.black,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const Text(
                'Qual seu tipo sanguíneo?',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlue,
                ),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildBloodTypeButton('A'),
                  _buildBloodTypeButton('B'),
                  _buildBloodTypeButton('AB'),
                  _buildBloodTypeButton('O'),
                ],
              ),
              const SizedBox(height: 80),
              Center(
                child: Text(
                  '${_selectedBloodType ?? ''}${_selectedRhFactor ?? ''}',
                  style: const TextStyle(
                    fontSize: 100,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 80),
              Row(
                children: [
                  _buildRhFactorButton('+'),
                  const SizedBox(width: 16),
                  _buildRhFactorButton('-'),
                ],
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ComorbidadePaciente()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue.shade400,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
