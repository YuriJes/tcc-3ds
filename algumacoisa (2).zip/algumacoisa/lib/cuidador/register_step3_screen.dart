import 'package:flutter/material.dart';
import 'register_step4_screen.dart'; // Importa a próxima tela

class RegisterStep3Screen extends StatefulWidget {
  const RegisterStep3Screen({super.key});

  @override
  _RegisterStep3ScreenState createState() => _RegisterStep3ScreenState();
}

class _RegisterStep3ScreenState extends State<RegisterStep3Screen> {
  String? _selectedGender;

  // Método auxiliar para campos de texto
  Widget _buildTextField(String hint,
      {TextInputType type = TextInputType.text, bool isPassword = false}) {
    return TextField(
      obscureText: isPassword,
      keyboardType: type,
      decoration: InputDecoration(
        hintText: hint,
        contentPadding:
            const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide(
            color: Colors.grey.shade300,
            width: 2,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide(
            color: Colors.grey.shade300,
            width: 2,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide(
            color: Colors.lightBlue.shade400,
            width: 2,
          ),
        ),
        filled: true,
        fillColor: Colors.white,
        suffixIcon: isPassword ? const Icon(Icons.visibility_off, color: Colors.black54) : null,
      ),
    );
  }

  // Método auxiliar para dropdowns
  InputDecoration _dropDownDecoration(String label) {
    return InputDecoration(
      labelText: label,
      contentPadding:
          const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.0),
        borderSide: BorderSide(
          color: Colors.grey.shade300,
          width: 2,
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.0),
        borderSide: BorderSide(
          color: Colors.grey.shade300,
          width: 2,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.0),
        borderSide: BorderSide(
          color: Colors.lightBlue.shade400,
          width: 2,
        ),
      ),
      filled: true,
      fillColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            const SizedBox(height: 20),
            const Text(
              'Cadastrar-se',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.lightBlue,
              ),
            ),
            const SizedBox(height: 40),

            const Text("Nome Completo", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu nome"),

            const SizedBox(height: 20),

            const Text("Email", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu email", type: TextInputType.emailAddress),

            const SizedBox(height: 20),

            const Text("Data de Nascimento", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    decoration: _dropDownDecoration("Dia"),
                    items: List.generate(31, (i) => i + 1)
                        .map((day) => DropdownMenuItem(
                              value: day,
                              child: Text(day.toString()),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: _dropDownDecoration("Mês"),
                    items: const ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
                        .map((month) => DropdownMenuItem(
                              value: month,
                              child: Text(month),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    decoration: _dropDownDecoration("Ano"),
                    items: List.generate(100, (i) => DateTime.now().year - i)
                        .map((year) => DropdownMenuItem(
                              value: year,
                              child: Text(year.toString()),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            const Text("Gênero", style: TextStyle(fontSize: 16, color: Colors.black54)),
            Row(
              children: [
                Radio<String>(
                  value: "F",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                  activeColor: Colors.lightBlue.shade400,
                ),
                const Text("Feminino"),
                Radio<String>(
                  value: "M",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                  activeColor: Colors.lightBlue.shade400,
                ),
                const Text("Masculino"),
                Radio<String>(
                  value: "O",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                  activeColor: Colors.lightBlue.shade400,
                ),
                const Text("Outro"),
              ],
            ),

            const SizedBox(height: 20),

            const Text("Telefone", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu telefone", type: TextInputType.phone),

            const SizedBox(height: 20),

            const Text("Endereço", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu endereço"),

            const SizedBox(height: 20),

            const Text("Senha", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Digite sua senha", isPassword: true),

            const SizedBox(height: 20),

            const Text("Confirme sua senha", style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 8),
            _buildTextField("Repita sua senha", isPassword: true),

            const SizedBox(height: 40),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterStep4Screen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.lightBlue.shade400,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5,
              ),
              child: const Text(
                "Cadastrar",
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}