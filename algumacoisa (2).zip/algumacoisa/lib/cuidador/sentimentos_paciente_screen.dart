import 'package:flutter/material.dart';
import 'sinais_clinicos_screen.dart';

class SentimentosPacienteScreen extends StatefulWidget {
  const SentimentosPacienteScreen({super.key});

  @override
  _SentimentosPacienteScreenState createState() => _SentimentosPacienteScreenState();
}

class _SentimentosPacienteScreenState extends State<SentimentosPacienteScreen> {
  String? _selectedSentiment;
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Dados do paciente para passar para a próxima tela
    Map<String, dynamic> patientData = {
      'nomePaciente': 'Henrique Bueno',
      'idadePaciente': '56 anos',
      'sentimentoSelecionado': _selectedSentiment ?? 'Nenhum selecionado',
      'notasBusca': _searchController.text,
    };

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        // A barra de progresso agora é o título do AppBar, como na outra tela
        title: LinearProgressIndicator(
          value: 0.55,
          backgroundColor: Colors.grey[300],
          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF62A7D2)),
        ),
        centerTitle: false, // O alinhamento central não é necessário quando o título é o único elemento
        actions: [
          TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SinaisClinicosScreen(),
                ),
              );
            },
            child: const Text('Próximo', style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage('https://randomuser.me/api/portraits/men/32.jpg'),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    patientData['nomePaciente'],
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(patientData['idadePaciente'], style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Estado geral desse paciente hoje:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar sentimentos...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                _buildSentimentButton('Muito bem', const Color(0xFF81C784)),
                const SizedBox(width: 10),
                _buildSentimentButton('Bem', const Color(0xFF4FC3F7)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                _buildSentimentButton('Mal', const Color(0xFFFFB74D)),
                const SizedBox(width: 10),
                _buildSentimentButton('Muito mal', const Color(0xFFE57373)),
              ],
            ),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SinaisClinicosScreen(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF62A7D2),
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text('Próximo'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSentimentButton(String text, Color color) {
    bool isSelected = _selectedSentiment == text;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedSentiment = text;
          });
        },
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16.0),
            border: isSelected
                ? Border.all(color: Colors.black, width: 3.0)
                : Border.all(color: Colors.transparent, width: 0),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 5,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
