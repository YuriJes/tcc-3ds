import 'package:flutter/material.dart';
import 'detalhes_agenda.dart'; // já importa sua tela de detalhes

class AgendaFamiliar extends StatelessWidget {
  const AgendaFamiliar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Agenda',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today_outlined),
            onPressed: () {
              // Abre a tela de detalhes
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const DetalhesAgenda(),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Barra de navegação por mês
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'DEZ',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.arrow_back_ios),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.arrow_forward_ios),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Calendário semanal
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildDayOfWeek('D', '19', false),
                  _buildDayOfWeek('S', '20', false),
                  _buildDayOfWeek('T', '21', false),
                  _buildDayOfWeek('Q', '22', true), // Dia selecionado
                  _buildDayOfWeek('Q', '23', false),
                  _buildDayOfWeek('S', '24', false),
                  _buildDayOfWeek('S', '25', false),
                ],
              ),
              const SizedBox(height: 24),
              // Linha de Hora e ícone de filtro
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Hora',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.sort),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Linha do tempo e consultas
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Linha do tempo (horários)
                  const Column(
                    children: [
                      Text('09:00'),
                      SizedBox(height: 10),
                      Text('09:30'),
                    ],
                  ),
                  const SizedBox(width: 20),
                  // Lista de consultas
                  Expanded(
                    child: Column(
                      children: [
                        // Card de consulta
                        _buildAppointmentCard(
                          context,
                          title: 'Consulta Médica',
                          subtitle: 'Cardiologista',
                          status: 'confirmado',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mail_outline),
            label: 'Mensagens',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle, size: 48, color: Colors.blue),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people_outline),
            label: 'Pacientes',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            label: 'Agenda',
          ),
        ],
        currentIndex: 4, // Seleciona "Agenda"
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
    );
  }

  // Widget para os dias da semana
  Widget _buildDayOfWeek(String day, String date, bool isSelected) {
    return Container(
      width: 40,
      height: 60,
      decoration: BoxDecoration(
        color: isSelected ? Colors.blue.shade100 : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected ? Colors.blue.shade700 : Colors.transparent,
          width: 2,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            day,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.blue.shade700 : Colors.grey,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            date,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: isSelected ? Colors.blue.shade700 : Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  // Widget para o cartão de consulta
  Widget _buildAppointmentCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required String status,
  }) {
    return InkWell(
      onTap: () {
        // Ao clicar no card -> abre a tela de detalhes
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DetalhesAgenda()),
        );
      },
      child: Card(
        color: Colors.blue.shade50,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Colors.blue.shade200, width: 2),
        ),
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const CircleAvatar(
                          child: Icon(Icons.person, size: 16, color: Colors.white),
                          backgroundColor: Colors.blue,
                          radius: 12,
                        ),
                        const SizedBox(width: 8),
                        const Text('Meu familiar'),
                        const SizedBox(width: 8),
                        Icon(
                          Icons.check_circle,
                          color: Colors.green.shade600,
                          size: 18,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                color: Colors.blue,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
