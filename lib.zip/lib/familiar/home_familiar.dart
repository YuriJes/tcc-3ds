import 'package:flutter/material.dart';
import 'package:semtepo/familiar/agenda_familiar.dart';
import 'package:semtepo/familiar/consultas_familiar.dart';
import 'package:semtepo/familiar/conversas_familiar.dart';
import 'package:semtepo/familiar/emergencias_familiar.dart';
import 'package:semtepo/familiar/medicamentos_familiar.dart';
import 'package:semtepo/familiar/meu_perfil_screen.dart';
import 'package:semtepo/familiar/notificacoes_screen.dart';
import 'package:semtepo/familiar/sentimentos_familiar.dart';
import 'package:semtepo/familiar/tarefas_familiar.dart';


class HomeFamiliar extends StatefulWidget {
  @override
  _HomeFamiliar createState() => _HomeFamiliar();
}

class _HomeFamiliar extends State<HomeFamiliar> {
  // Remova a variável _showOptions, pois não será mais usada.
  // bool _showOptions = false;

  // Remova a função _toggleOptions, pois não será mais usada.
  // void _toggleOptions() {
  //   setState(() {
  //     _showOptions = !_showOptions;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFFB3E5FC),
                Color(0xFF81D4FA),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MeuPerfilfamiliar()),
                    );
                  },
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundImage: AssetImage('assets/carolina.png'),
                        radius: 24,
                      ),
                      SizedBox(width: 12),
                      Text(
                        'Bem-vindo, Yuri (Familiar)',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.notifications_none, color: Colors.white),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => NotificacoesFamiliar()),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: <Widget>[
            _buildInfoCard(
              context: context,
              icon: Icons.access_time,
              title: 'Consultas Hoje',
              subtitle: '2 Agendadas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ConsultasFamiliar()),
                );
              },
            ),
            _buildInfoCard(
              context: context,
              icon: Icons.medical_services_outlined,
              title: 'Medicamentos a administrar',
              subtitle: '2 Horários',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MedicamentosFamiliar()),
                );
              },
            ),
            _buildInfoCard(
              context: context,
              icon: Icons.warning_amber_outlined,
              title: 'Emergências recentes',
              subtitle: '1 Alerta hoje',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EmergenciasFamiliar()),
                );
              },
            ),
            _buildInfoCard(
              context: context,
              icon: Icons.task_alt,
              title: 'Tarefas Pendentes',
              subtitle: '2 Tarefas',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TarefasFamiliar()),
                );
              },
            ),
            _buildInfoCard(
              context: context,
              icon: Icons.sick_outlined,
              title: 'Sentimentos Paciente',
              subtitle: '2 sintomas hoje',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SentimentosFamiliar()),
                );
              },
            ),
          ],
        ),
      ),
      // Remova o FloatingActionButton
      // floatingActionButton: FloatingActionButton(
      //   onPressed: _toggleOptions,
      //   child: Icon(_showOptions ? Icons.close : Icons.add),
      //   backgroundColor: Colors.lightBlue,
      // ),
      // Remova a localização do FloatingActionButton
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        // Remova o 'shape: CircularNotchedRectangle()'. Isso é usado para criar
        // o recorte para o FloatingActionButton.
        // shape: CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.home, color: Colors.blue),
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst);
              },
            ),
            IconButton(
              icon: Icon(Icons.message_outlined, color: Colors.blue),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ConversasFamiliar()),
                );
              },
            ),
            // Remova o SizedBox que ocupava o espaço do FloatingActionButton.
            // SizedBox(width: 48),

            IconButton(
              icon: Icon(Icons.calendar_today_outlined, color: Colors.grey),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AgendaFamiliar()),
                );
              },
            ),
            // Adicione um novo botão para manter a simetria e o espaçamento correto.
           
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
  }) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Icon(icon, size: 40, color: Colors.blue.shade700),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    SizedBox(height: 4),
                    Text(subtitle),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  // Remova o Widget _buildAnimatedFloatingButton, pois ele não é mais necessário.
  // Widget _buildAnimatedFloatingButton({
  //   required IconData icon,
  //   required bool isVisible,
  //   required double offset,
  //   required VoidCallback onPressed,
  // }) {
  //   return AnimatedContainer(
  //     duration: Duration(milliseconds: 300),
  //     curve: Curves.easeOut,
  //     transform: Matrix4.translationValues(0.0, isVisible ? -offset : 0.0, 0.0),
  //     child: AnimatedOpacity(
  //       opacity: isVisible ? 1.0 : 0.0,
  //       duration: Duration(milliseconds: 300),
  //       child: FloatingActionButton(
  //         mini: true,
  //         heroTag: null,
  //         onPressed: isVisible ? onPressed : null,
  //         child: Icon(icon),
  //       ),
  //     ),
  //   );
  // }
}
