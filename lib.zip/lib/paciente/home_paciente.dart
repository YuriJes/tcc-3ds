import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // A cor de fundo da AppBar pode ser ajustada para combinar com a imagem.
        backgroundColor: Colors.white,
        elevation: 0, // Remove a sombra
        title: Row(
          children: const [
            CircleAvatar(
              // Imagem de perfil do usuário. Use uma imagem local.
              backgroundImage: AssetImage('assets/images/user_avatar.png'),
            ),
            SizedBox(width: 10),
            Text(
              'Bem-vinda, Carolina.',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.blue),
            onPressed: () {
              // Ação para o clique no sino de notificação.
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Seção de Emergência
              Center(
                child: Column(
                  children: const [
                    // Ícone de emergência. Pode ser um ícone de um pacote ou uma imagem personalizada.
                    Icon(Icons.warning, color: Colors.red, size: 80),
                    Text(
                      'Emergência',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Seção de Tarefas de Hoje
              const Text(
                'Hoje:',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Tarefas:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 10),
              // Card da Tarefa
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 2,
                child: ListTile(
                  leading: const Icon(Icons.check_circle, color: Colors.blue),
                  title: const Text('Caminhar pela manhã'),
                  trailing: Checkbox(
                    value: true,
                    onChanged: (bool? value) {
                      // Lida com a mudança de estado do checkbox
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Seção de Medicamentos
              const Text(
                'Medicamentos:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 10),
              // Card do Medicamento
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 2,
                child: ListTile(
                  leading: const Icon(Icons.medical_services, color: Colors.grey),
                  title: const Text('Aspirina'),
                  subtitle: const Text('Um comprimido - 8:00 AM'),
                ),
              ),
              const SizedBox(height: 20),

              // Seção de Consultas
              const Text(
                'Consultas:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 10),
              // Card da Consulta
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 2,
                child: ListTile(
                  leading: const Icon(Icons.person, color: Colors.grey),
                  title: const Text('Cardiologista'),
                  subtitle: const Text('7:00 AM'),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Agenda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mail),
            label: 'Mensagens',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sentiment_satisfied),
            label: 'Sentimentos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sick),
            label: 'Sintomas',
          ),
        ],
        currentIndex: 2, // 'Home' é o terceiro item
        selectedItemColor: Colors.blue, // Cor do ícone ativo
        unselectedItemColor: Colors.grey, // Cor do ícone inativo
      ),import ‘package:flutter/material.dart’;

Class CadastroScreen extends StatelessWidget {
  Final Widget content;
  Final int step;
  Final int totalSteps = 5;

  Const CadastroScreen({
    Super.key,
    Required this.content,
    Required this.step,
  });

  @override
  Widget build(BuildContext context) {
    Return Scaffold(
      Body: SafeArea(
        Child: Padding(
          Padding: const EdgeInsets.all(20.0),
          Child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Barra de Progresso
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    Icon: const Icon(Icons.arrow_back_ios),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    Child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: step / totalSteps,
                        backgroundColor: Colors.grey[300],
                        valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF80D0E1)),
                        minHeight: 10,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      // Lógica para pular o passo
                    },
                    Child: const Text(‘Pular’),
                  ),
                ],
              ),
              Const SizedBox(height: 40),

              // Título (já foi adicionado nos widgets de conteúdo)

              // Conteúdo Dinâmico de Cada Tela
              Expanded(
                Child: Center(
                  Child: content,
                ),
              ),

              // Botão de Continuar
              SizedBox(
                Width: double.infinity,
                Child: ElevatedButton(
                  onPressed: () {
                    // Lógica para ir para a próxima tela
                  },
                  Style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF80D0E1),
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  Child: const Text(
                    ‘Continue’,
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
    );
  }
}
