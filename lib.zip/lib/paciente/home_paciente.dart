import 'package:flutter/material.dart';
import 'package:semtepo/paciente/agenda_paciente.dart';
import 'package:semtepo/paciente/emergencia_paciente.dart';
import 'package:semtepo/paciente/mensagems_paciente.dart';
import 'package:semtepo/paciente/perfil_paciente.dart';
import 'package:semtepo/paciente/sentimentos_paciente.dart';
import 'package:semtepo/paciente/sintomas_paciente.dart';


class HomePaciente extends StatefulWidget {
  const HomePaciente({super.key});

  @override
  _HomePacienteState createState() => _HomePacienteState();
}

class _HomePacienteState extends State<HomePaciente> {
  int _selectedIndex = 2;
  bool _showOptions = false;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(context, MaterialPageRoute(builder: (context) => const AgendaPaciente()));
        break;
      case 1:
        Navigator.push(context, MaterialPageRoute(builder: (context) => MensagemsPaciente()));
        break;
      case 3:
        Navigator.push(context, MaterialPageRoute(builder: (context) => SentimentosPaciente()));
        break;
      case 4:
        Navigator.push(context, MaterialPageRoute(builder: (context) => SintomasPaciente()));
        break;
    }
  }

  void _toggleOptions() {
    setState(() {
      _showOptions = !_showOptions;
    });
  }

  void _showEmergencyDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Tem certeza de que deseja enviar um alerta de emergência?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                   Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EmergenciaPaciente()),
                );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: const Text(
                    'SIM, PRECISO DE AJUDA',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: const Text(
                    'CANCELAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _buildInfoCard(
                  context: context,
                  icon: Icons.warning_amber_outlined,
                  title: 'Emergência',
                  subtitle: 'Clique para pedir ajuda',
                  iconColor: Colors.red,
                  onTap: _showEmergencyDialog, // Chama a função do diálogo aqui
                ),
                const SizedBox(height: 20),
                const Text(
                  'Hoje:',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                _buildInfoCard(
                  context: context,
                  icon: Icons.task_alt,
                  title: 'Caminhar pela manhã',
                  subtitle: 'Tarefa pendente',
                  iconColor: const Color(0xFF63B3ED),
                  onTap: () {},
                ),
                _buildInfoCard(
                  context: context,
                  icon: Icons.medical_services_outlined,
                  title: 'Aspirina',
                  subtitle: 'Um comprimido - 8:00 AM',
                  iconColor: const Color(0xFF63B3ED),
                  onTap: () {},
                ),
                _buildInfoCard(
                  context: context,
                  icon: Icons.person_pin_outlined,
                  title: 'Cardiologista',
                  subtitle: 'Consulta - 7:00 AM',
                  iconColor: const Color(0xFF63B3ED),
                  onTap: () {},
                ),
                const SizedBox(height: 100),
              ],
            ),
          ),
          Positioned(
            bottom: 80,
            right: 16,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildAnimatedFloatingButton(
                  icon: Icons.medical_services_outlined,
                  isVisible: _showOptions,
                  onPressed: () {},
                ),
                _buildAnimatedFloatingButton(
                  icon: Icons.task_alt,
                  isVisible: _showOptions,
                  onPressed: () {},
                ),
                _buildAnimatedFloatingButton(
                  icon: Icons.calendar_today_outlined,
                  isVisible: _showOptions,
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toggleOptions,
        backgroundColor: const Color(0xFF63B3ED),
        child: Icon(_showOptions ? Icons.close : Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      toolbarHeight: 100,
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFB3E5FC),
              Color(0xFF81D4FA),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PerfilPaciente()),
                  );
                },
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundImage: AssetImage('assets/carolina.png'),
                      radius: 24,
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Bem-vinda, Carolina.',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.notifications_none, color: Colors.white),
                onPressed: () {
                  // Ação para notificações
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color iconColor,
    VoidCallback? onTap,
  }) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Icon(icon, size: 40, color: iconColor),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 4),
                    Text(subtitle),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          IconButton(
            icon: Icon(Icons.calendar_today_outlined, color: _selectedIndex == 0 ? const Color(0xFF63B3ED) : Colors.grey),
            onPressed: () => _onItemTapped(0),
          ),
          IconButton(
            icon: Icon(Icons.mail_outline, color: _selectedIndex == 1 ? const Color(0xFF63B3ED) : Colors.grey),
            onPressed: () => _onItemTapped(1),
          ),
          const SizedBox(width: 48),
          IconButton(
            icon: Icon(Icons.sentiment_satisfied_outlined, color: _selectedIndex == 3 ? const Color(0xFF63B3ED) : Colors.grey),
            onPressed: () => _onItemTapped(3),
          ),
          IconButton(
            icon: Icon(Icons.sick_outlined, color: _selectedIndex == 4 ? const Color(0xFF63B3ED) : Colors.grey),
            onPressed: () => _onItemTapped(4),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedFloatingButton({
    required IconData icon,
    required bool isVisible,
    required VoidCallback onPressed,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
      transform: Matrix4.translationValues(0.0, isVisible ? -20.0 : 0.0, 0.0),
      child: AnimatedOpacity(
        opacity: isVisible ? 1.0 : 0.0,
        duration: const Duration(milliseconds: 300),
        child: FloatingActionButton(
          mini: true,
          heroTag: null,
          onPressed: isVisible ? onPressed : null,
          backgroundColor: Colors.white,
          child: Icon(icon, color: const Color(0xFF63B3ED)),
        ),
      ),
    );
  }
}