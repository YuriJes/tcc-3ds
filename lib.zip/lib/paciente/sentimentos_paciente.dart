import 'package:flutter/material.dart';

class SentimentosPaciente extends StatefulWidget {
  @override
  _SentimentosPacienteState createState() => _SentimentosPacienteState();
}

class _SentimentosPacienteState extends State<SentimentosPaciente> {
  String? _selectedEmotion;

  Widget _buildEmotionCard(String emotion, Color color) {
    bool isSelected = _selectedEmotion == emotion;
    return InkWell(
      onTap: () {
        setState(() {
          _selectedEmotion = isSelected ? null : emotion;
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16.0),
          border: isSelected
              ? Border.all(color: Colors.blueAccent, width: 4.0)
              : null,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              emotion == 'Raiva'
                  ? '😡'
                  : emotion == 'Alegria'
                      ? '😁'
                      : emotion == 'Medo'
                          ? '😨'
                          : '😔',
              style: TextStyle(fontSize: 60),
            ),
            SizedBox(height: 8),
            Text(
              emotion,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Sentimentos',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          TextButton(
            onPressed: () {
              // Ação de enviar
            },
            child: Text(
              'Enviar',
              style: TextStyle(
                color: Colors.blue,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quais sentimentos\nvocê está sentindo?',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.blue[800],
              ),
            ),
            SizedBox(height: 24),
            TextField(
              decoration: InputDecoration(
                hintText: 'Buscar sentimentos...',
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
              ),
            ),
            SizedBox(height: 16),
            Wrap(
              spacing: 8.0,
              children: [
                Chip(label: Text('Raiva')),
              ],
            ),
            SizedBox(height: 24),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                children: [
                  _buildEmotionCard('Raiva', Colors.red[600]!),
                  _buildEmotionCard('Alegria', Colors.yellow[600]!),
                  _buildEmotionCard('Medo', Colors.deepPurple[400]!),
                  _buildEmotionCard('Tristeza', Colors.blue[600]!),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}