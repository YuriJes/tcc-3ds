import 'package:flutter/material.dart';
import 'package:semtepo/paciente/perfil_paciente.dart';

class InformacoesPessoais extends StatelessWidget {
  const InformacoesPessoais({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
         Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PerfilPaciente()),
                );
          },
        ),
        title: const Text('Edit Profile'),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Informações Pessoais',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            _buildInfoCard('Idade', '35 Anos'),
            const SizedBox(height: 10),
            _buildInfoCard('Tipo Sanguíneo', 'A+'),
            const SizedBox(height: 10),
            _buildInfoCard('Problemas De Saúde', 'Diabetes, Asma, Ansiedade'),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _buildInfoCard('Altura', '1,56m')),
                const SizedBox(width: 10),
                Expanded(child: _buildInfoCard('Peso', '76kg')),
              ],
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Ação para atualizar
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan[600],
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text('Atualizar', style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.blueAccent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 16, color: Colors.black54)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}