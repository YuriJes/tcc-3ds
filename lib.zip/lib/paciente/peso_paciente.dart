import 'package:flutter/material.dart';
import 'package:semtepo/paciente/idade_paciente.dart';

class PesoPaciente extends StatefulWidget {
  const PesoPaciente({super.key});

  @override
  State<PesoPaciente> createState() => _WeightScreenState();
}

class _WeightScreenState extends State<PesoPaciente> {
  double _currentWeight = 140.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comprehensive Health Assessment'),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('Pular', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Qual é o seu peso?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            Center(
              child: Column(
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: _currentWeight.toStringAsFixed(0),
                          style: const TextStyle(
                            fontSize: 80,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        const TextSpan(
                          text: ' Kg',
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  SliderTheme(
                    data: const SliderThemeData(
                      thumbColor: Colors.blueAccent,
                      activeTrackColor: Colors.blueAccent,
                      inactiveTrackColor: Colors.grey,
                      trackHeight: 2,
                    ),
                    child: Slider(
                      value: _currentWeight,
                      min: 30,
                      max: 200,
                      divisions: 170,
                      onChanged: (double value) {
                        setState(() {
                          _currentWeight = value;
                        });
                      },
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('130', style: TextStyle(color: Colors.grey[600])),
                      Text('150', style: TextStyle(color: Colors.grey[600])),
                    ],
                  ),
                ],
              ),
            ),
            const Spacer(),
            ElevatedButton(
            onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => IdadePaciente()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text('Continue', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}