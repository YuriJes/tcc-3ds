import 'package:flutter/material.dart';
import 'sanguineo_paciente.dart';

class IdadePaciente extends StatefulWidget {
  const IdadePaciente({super.key});

  @override
  State<IdadePaciente> createState() => _AgeScreenState();
}

class _AgeScreenState extends State<IdadePaciente> {
  final FixedExtentScrollController _scrollController = FixedExtentScrollController(initialItem: 19);
  int _currentAge = 19;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comprehensive Health Assessment'),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('Pular', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Qual é a sua idade?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            SizedBox(
              height: 200,
              child: ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: 70,
                perspective: 0.005,
                physics: const FixedExtentScrollPhysics(),
                onSelectedItemChanged: (index) {
                  setState(() {
                    _currentAge = index;
                  });
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  builder: (context, index) {
                    final isSelected = index == _currentAge;
                    return Center(
                      child: Text(
                        index.toString(),
                        style: TextStyle(
                          fontSize: isSelected ? 48 : 24,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          color: isSelected ? Colors.blueAccent : Colors.grey,
                        ),
                      ),
                    );
                  },
                  childCount: 100,
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton(
          onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SanguineoPaciente()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text('Continue', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}