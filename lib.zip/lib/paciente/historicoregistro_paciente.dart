import 'package:flutter/material.dart';
import 'package:semtepo/paciente/perfil_paciente.dart';

class HistoricoDeRegistros extends StatelessWidget {
  const HistoricoDeRegistros({super.key});

  Widget _buildRecordCard(String title, String date, String description) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                date,
                style: const TextStyle(fontSize: 14, color: Colors.black54),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(description, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(
              onPressed: () {
                // Ação para verificar o registro
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.lightBlue.shade400,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              child: const Text('Verificar', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Text(
              'Histórico De Registros',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.lightBlue,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Data:', style: TextStyle(fontSize: 16)),
                TextButton(
                  onPressed: () {},
                  child: Text(
                    'Todas',
                    style: TextStyle(color: Colors.lightBlue.shade400),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: [
                  _buildRecordCard('Consulta', '15/10/2025', 'Cuidador Registrou uma nova consulta\nMedico: Cardiologista\nData: 19/10/25...'),
                  const SizedBox(height: 16),
                  _buildRecordCard('Sintomas', '15/10/2025', 'Você registrou um novo sintoma\nDores de Cabeça'),
                  const SizedBox(height: 16),
                  _buildRecordCard('Consulta', '15/10/2025', 'Cuidador Registrou uma nova consulta\nCuidador Registrou uma nova consulta\nDores de Cabeça'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}