import 'package:flutter/material.dart';
import 'package:semtepo/paciente/perfil_paciente.dart';

class HistoricoDeRegistros extends StatelessWidget {
  const HistoricoDeRegistros({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PerfilPaciente()),
                );
          },
        ),
        title: const Text('Edit Profile'),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Histórico De Registros',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Data:', style: TextStyle(fontSize: 16)),
                TextButton(
                  onPressed: () {},
                  child: const Text('Todas', style: TextStyle(color: Colors.blue)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: [
                  _buildRecordCard('Consulta', '15/10/2025', 'Cuidador Registrou uma nova consulta\nMedico: Cardiologista\nData: 19/10/25...'),
                  const SizedBox(height: 16),
                  _buildRecordCard('Sintomas', '15/10/2025', 'Você registrou um novo sintoma\nDores de Cabeça'),
                  const SizedBox(height: 16),
                  _buildRecordCard('Consulta', '15/10/2025', 'Cuidador Registrou uma nova consulta\nCuidador Registrou uma nova consulta\nDores de Cabeça'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecordCard(String title, String date, String description) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.blueAccent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(date, style: const TextStyle(fontSize: 14, color: Colors.black54)),
            ],
          ),
          const SizedBox(height: 8),
          Text(description, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(
              onPressed: () {
                // Ação para verificar o registro
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('Verificar', style: TextStyle(color: Colors.blue)),
            ),
          ),
        ],
      ),
    );
  }
}