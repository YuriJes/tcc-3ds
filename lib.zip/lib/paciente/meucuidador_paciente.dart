import 'package:flutter/material.dart';
import 'package:semtepo/paciente/perfil_paciente.dart';

class MeuCuidador extends StatelessWidget {
  const MeuCuidador({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
           Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PerfilPaciente()),
                );
          },
        ),
        title: const Text('Edit Profile'),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Text(
              'Meu Cuidador',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            const CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage('assets/profile_pic.png'), // Imagem de exemplo
            ),
            const SizedBox(height: 20),
            _buildContactInfo('Nome Completo', 'Mark Sloan Torres'),
            const SizedBox(height: 10),
            _buildContactInfo('Numero De Telefone', '+666 999 99999'),
            const SizedBox(height: 10),
            _buildContactInfo('Email', 'mark@gmail.com'),
            const SizedBox(height: 20),
            const Text(
              'Data Dos Cuidados',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 4),
            const Text(
              'Desde 03/11/2024',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactInfo(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, color: Colors.black54)),
        const SizedBox(height: 4),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.blueAccent.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }
}