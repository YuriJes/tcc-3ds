import 'package:flutter/material.dart';
import 'package:semtepo/paciente/login_screen%20copy.dart';


void main() {
  runApp(const ComorbidadePaciente());
}

class ComorbidadePaciente extends StatelessWidget {
  const ComorbidadePaciente({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HealthAssessmentScreen(),
    );
  }
}

class HealthAssessmentScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              // Header com seta de voltar, barra de progresso e botão "Pular"
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
                    onPressed: () {
                      // Ação para voltar
                    },
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: LinearProgressIndicator(
                        value: 0.5, // Ajuste o valor para a posição do progresso
                        backgroundColor: Colors.grey[300],
                        color: const Color(0xFF63B3ED), // Cor azul do progresso
                        minHeight: 8.0,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      // Ação para pular
                    },
                    child: const Text(
                      'Pular',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 50),
              // Título
              const Text(
                'Cite se tiver alguma\ncomorbidade ou\ntranstorno:',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 30),
              // Campo de texto
              Expanded(
                child: TextField(
                  maxLines: null, // Permite múltiplas linhas
                  expands: true,
                  decoration: InputDecoration(
                    hintText: 'Descreva:',
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0xFFE3F2FD), // Cor azul claro do campo de texto
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Botão "Continue"
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPaciente()),
                );
              },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF63B3ED), // Cor azul do botão
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}