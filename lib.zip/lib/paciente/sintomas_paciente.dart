import 'package:flutter/material.dart';

class SintomasPaciente extends StatefulWidget {
  @override
  _SintomasPacienteState createState() => _SintomasPacienteState();
}

class _SintomasPacienteState extends State<SintomasPaciente> {
  String? _selectedSymptom;

  Widget _buildSymptomCard(String symptom, Color color) {
    bool isSelected = _selectedSymptom == symptom;
    return InkWell(
      onTap: () {
        setState(() {
          _selectedSymptom = isSelected ? null : symptom;
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16.0),
          border: isSelected
              ? Border.all(color: Colors.blueAccent, width: 4.0)
              : null,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              symptom == 'Dor de cabeça'
                  ? '🤕'
                  : symptom == 'Febre'
                      ? '🤒'
                      : symptom == 'Náusea'
                          ? '🤢'
                          : '😵',
              style: TextStyle(fontSize: 60),
            ),
            SizedBox(height: 8),
            Text(
              symptom,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Sintomas',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          TextButton(
            onPressed: () {
              // Ação de enviar
            },
            child: Text(
              'Enviar',
              style: TextStyle(
                color: Colors.blue,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quais sintomas\nvocê está sentindo?',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.blue[800],
              ),
            ),
            SizedBox(height: 24),
            TextField(
              decoration: InputDecoration(
                hintText: 'Buscar sintomas...',
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
              ),
            ),
            SizedBox(height: 16),
            Wrap(
              spacing: 8.0,
              children: [
                Chip(label: Text('Dor de cabeça')),
                Chip(label: Text('Febre')),
              ],
            ),
            SizedBox(height: 24),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                children: [
                  _buildSymptomCard('Dor de cabeça', Colors.red[600]!),
                  _buildSymptomCard('Febre', Colors.yellow[600]!),
                  _buildSymptomCard('Náusea', Colors.green[600]!),
                  _buildSymptomCard('Tontura', Colors.deepPurple[400]!),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}