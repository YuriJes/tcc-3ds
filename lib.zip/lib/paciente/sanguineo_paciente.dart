import 'package:flutter/material.dart';
import 'package:semtepo/paciente/altura_paciente.dart';
import 'package:semtepo/paciente/comorbidade_paciente.dart';

class SanguineoPaciente extends StatefulWidget {
  const SanguineoPaciente({super.key});

  @override
  State<SanguineoPaciente> createState() => _BloodTypeScreenState();
}

class _BloodTypeScreenState extends State<SanguineoPaciente> {
  String? _selectedBloodType;
  String? _selectedRhFactor;

  Widget _buildBloodTypeButton(String type) {
    final isSelected = _selectedBloodType == type;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedBloodType = type;
        });
      },
      child: Container(
        width: 60,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected ? Colors.blueAccent.withOpacity(0.2) : Colors.grey[200],
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          type,
          style: TextStyle(
            color: isSelected ? Colors.blueAccent : Colors.black,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildRhFactorButton(String factor) {
    final isSelected = _selectedRhFactor == factor;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedRhFactor = factor;
          });
        },
        child: Container(
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: isSelected ? Colors.blueAccent.withOpacity(0.2) : Colors.grey[200],
            borderRadius: BorderRadius.circular(30),
          ),
          child: Text(
            factor,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.blueAccent : Colors.black,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comprehensive Health Assessment'),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('Pular', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Qual seu tipo sanguíneo?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildBloodTypeButton('A'),
                _buildBloodTypeButton('B'),
                _buildBloodTypeButton('AB'),
                _buildBloodTypeButton('O'),
              ],
            ),
            const Spacer(),
            Center(
              child: Text(
                '${_selectedBloodType ?? ''}${_selectedRhFactor ?? ''}',
                style: const TextStyle(fontSize: 100, fontWeight: FontWeight.bold),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                _buildRhFactorButton('+'),
                const SizedBox(width: 16),
                _buildRhFactorButton('-'),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
             onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ComorbidadePaciente()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text('Continue', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}