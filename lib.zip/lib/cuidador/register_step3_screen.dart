import 'package:flutter/material.dart';
import 'register_step4_screen.dart'; // Importa a próxima tela

class RegisterStep3Screen extends StatefulWidget {
  @override
  _RegisterStep3ScreenState createState() => _RegisterStep3ScreenState();
}

class _RegisterStep3ScreenState extends State<RegisterStep3Screen> {
  String? _selectedGender;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text('Cadastrar-se'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            const SizedBox(height: 20),

            // Nome
            const Text("Nome Completo", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu nome"),

            const SizedBox(height: 20),

            // Email
            const Text("Email", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu email", type: TextInputType.emailAddress),

            const SizedBox(height: 20),

            // Data de nascimento
            const Text("Data de Nascimento", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    decoration: _dropDownDecoration("Dia"),
                    items: List.generate(31, (i) => i + 1)
                        .map((day) => DropdownMenuItem(
                              value: day,
                              child: Text(day.toString()),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: _dropDownDecoration("Mês"),
                    items: ["Janeiro", "Fevereiro", "Março"]
                        .map((month) => DropdownMenuItem(
                              value: month,
                              child: Text(month),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    decoration: _dropDownDecoration("Ano"),
                    items: [2023, 2022, 2021, 2000, 1990]
                        .map((year) => DropdownMenuItem(
                              value: year,
                              child: Text(year.toString()),
                            ))
                        .toList(),
                    onChanged: (value) {},
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Gênero
            const Text("Gênero", style: TextStyle(fontSize: 16)),
            Row(
              children: [
                Radio<String>(
                  value: "F",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                ),
                const Text("Feminino"),
                Radio<String>(
                  value: "M",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                ),
                const Text("Masculino"),
                Radio<String>(
                  value: "O",
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() => _selectedGender = value);
                  },
                ),
                const Text("Outro"),
              ],
            ),

            const SizedBox(height: 20),

            // Telefone
            const Text("Telefone", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu telefone", type: TextInputType.phone),

            const SizedBox(height: 20),

            // Endereço
            const Text("Endereço", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Digite seu endereço"),

            const SizedBox(height: 20),

            // Senha
            const Text("Senha", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Digite sua senha", isPassword: true),

            const SizedBox(height: 20),

            // Confirmar senha
            const Text("Confirme sua senha", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            _buildTextField("Repita sua senha", isPassword: true),

            const SizedBox(height: 40),

            // Botão
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterStep4Screen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade400,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5,
              ),
              child: const Text(
                "Cadastrar",
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Método auxiliar para campos de texto
  Widget _buildTextField(String hint,
      {TextInputType type = TextInputType.text, bool isPassword = false}) {
    return TextField(
      obscureText: isPassword,
      keyboardType: type,
      decoration: InputDecoration(
        hintText: hint,
        contentPadding:
            const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.blue.shade50,
        suffixIcon: isPassword ? const Icon(Icons.visibility_off) : null,
      ),
    );
  }

  // Método auxiliar para dropdowns
  InputDecoration _dropDownDecoration(String label) {
    return InputDecoration(
      labelText: label,
      contentPadding:
          const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10.0),
        borderSide: BorderSide.none,
      ),
      filled: true,
      fillColor: Colors.blue.shade50,
    );
  }
}
